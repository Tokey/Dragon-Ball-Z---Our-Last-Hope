﻿using System.Xml.Serialization;
using System.Collections.Generic;

[XmlType(Namespace = "http://schemas.ali.com/lib/")]
[XmlRoot("Library", Namespace = "http://schemas.ali.com/lib/", IsNullable = false)]
public partial class LibraryType
{
    private BooksType booksField;
    private EmployeesType employeesField;
    
    public BooksType Books
    {
        get
        {
            return this.booksField;
        }
        set
        {
            this.booksField = value;
        }
    }
    
    public EmployeesType Employees
    {
        get
        {
            return this.employeesField;
        }
        set
        {
            this.employeesField = value;
        }
    }
}

[XmlType(Namespace = "http://schemas.ali.com/lib/")]
public partial class BooksType
{
    private List<BookType> bookField;
    
    [XmlElement("Book")]
    public List<BookType> Book
    {
        get
        {
            return this.bookField;
        }
        set
        {
            this.bookField = value;
        }
    }
}

[XmlType(Namespace = "http://schemas.ali.com/lib/")]
public partial class BookType
{
    private string titleField;
    private string authorField;
    
    [XmlAttribute()]
    public string Title
    {
        get
        {
            return this.titleField;
        }
        set
        {
            this.titleField = value;
        }
    }
    
    [XmlAttribute()]
    public string Author
    {
        get
        {
            return this.authorField;
        }
        set
        {
            this.authorField = value;
        }
    }
}

[XmlType(Namespace = "http://schemas.ali.com/lib/")]
public partial class EmployeeType
{
    private string nameField;
    
    [XmlAttribute()]
    public string Name
    {
        get
        {
            return this.nameField;
        }
        set
        {
            this.nameField = value;
        }
    }
}

[XmlType(Namespace = "http://schemas.ali.com/lib/")]
public partial class EmployeesType
{
    private List<EmployeeType> employeeField;

    [XmlElement("Employee")]
    public List<EmployeeType> Employee
    {
        get
        {
            return this.employeeField;
        }
        set
        {
            this.employeeField = value;
        }
    }
}
